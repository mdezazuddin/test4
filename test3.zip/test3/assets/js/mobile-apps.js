$(function(){ 
    // swiper-master    
    var swiper4 = new Swiper( '.swiper4', {
        spaceBetween: 20,
        loop: true,
        slidesPerView: 1,

        autoplay: {
            delay: 5000,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
      }, 
      
      // Responsive breakpoints
      breakpoints: {
        // when window width is <= 480px
        480: {
          slidesPerView: 1,
          spaceBetween: 20
        },
        // when window width is <= 640px
        768: {
          slidesPerView: 2,
          spaceBetween: 20
        },
        // when window width is <= 640px
        992: {
          slidesPerView: 3,
          spaceBetween: 20
        }
      },  
    } );

 });